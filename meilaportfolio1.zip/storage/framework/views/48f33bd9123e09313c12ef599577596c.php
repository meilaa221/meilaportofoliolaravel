<div class="bg-gray-50 rounded-lg shadow-lg p-6 hover:shadow-xl transition duration-300">
    <h3 class="text-xl font-bold text-gray-800 mb-3"><?php echo e($project['title']); ?></h3>
    <p class="text-gray-600 mb-4 text-justify"><?php echo e($project['description']); ?></p>
    <div class="flex flex-wrap gap-2">
        <?php $__currentLoopData = $project['tech_stack']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="bg-primary text-white px-3 py-1 rounded-full text-sm"><?php echo e($tech); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\Users\dgtme\meila-portfolio\resources\views/portfolio/components/project-card.blade.php ENDPATH**/ ?>