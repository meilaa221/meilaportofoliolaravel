<div class="bg-white rounded-lg shadow-lg p-6">
    <div class="text-center mb-6">
        <i class="<?php echo e($icon); ?> text-4xl text-primary mb-4"></i>
        <h3 class="text-xl font-bold text-gray-800"><?php echo e($title); ?></h3>
    </div>
    <ul class="space-y-3">
        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex items-center">
                <i class="fas fa-check-circle text-primary mr-3"></i>
                <span class="text-gray-600"><?php echo e($skill); ?></span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH C:\Users\dgtme\meila-portfolio\resources\views/portfolio/components/skill-card.blade.php ENDPATH**/ ?>