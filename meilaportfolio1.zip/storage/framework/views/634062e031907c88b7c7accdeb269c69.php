<!-- Education Section -->
<section id="education" class="py-20 bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Education</h2>
            <div class="w-20 h-1 bg-primary mx-auto"></div>
        </div>
        <div class="max-w-4xl mx-auto">
            <div class="bg-white rounded-lg shadow-lg p-8">
                <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                    <div>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2"><?php echo e($data['education']['university']); ?></h3>
                        <p class="text-lg text-primary font-semibold"><?php echo e($data['education']['major']); ?></p>
                    </div>
                    <div class="mt-4 md:mt-0 text-right">
                        <p class="text-lg font-bold text-accent">GPA: <?php echo e($data['education']['gpa']); ?></p>
                        <p class="text-gray-600"><?php echo e($data['education']['period']); ?></p>
                    </div>
                </div>
                <div>
                    <h4 class="text-lg font-semibold text-gray-800 mb-3">Mata Kuliah Relevan:</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                        <?php $__currentLoopData = $data['education']['relevant_courses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-center">
                                <i class="fas fa-check-circle text-primary mr-2"></i>
                                <span class="text-gray-600"><?php echo e($course); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\dgtme\meila-portfolio\resources\views/portfolio/components/education.blade.php ENDPATH**/ ?>