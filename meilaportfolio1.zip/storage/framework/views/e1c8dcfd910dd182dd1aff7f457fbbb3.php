<!-- Skills Section -->
<section id="skills" class="py-20 bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Technical Skills</h2>
            <div class="w-20 h-1 bg-primary mx-auto"></div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php echo $__env->make('portfolio.components.skill-card', [
                'title' => 'Frontend',
                'icon' => 'fas fa-code',
                'skills' => $data['skills']['frontend']
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->make('portfolio.components.skill-card', [
                'title' => 'Backend',
                'icon' => 'fas fa-server',
                'skills' => $data['skills']['backend']
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->make('portfolio.components.skill-card', [
                'title' => 'DevOps',
                'icon' => 'fas fa-cogs',
                'skills' => $data['skills']['devops']
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\dgtme\meila-portfolio\resources\views/portfolio/components/skills.blade.php ENDPATH**/ ?>