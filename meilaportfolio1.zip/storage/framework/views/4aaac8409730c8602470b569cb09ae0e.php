<!-- Experience & Achievements Section -->
<section id="experience" class="py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Experience & Achievements</h2>
            <div class="w-20 h-1 bg-primary mx-auto"></div>
        </div>
        
        <!-- Organization Experience -->
        <div class="max-w-4xl mx-auto mb-12">
            <div class="bg-gray-50 rounded-lg shadow-lg p-8">
                <h3 class="text-2xl font-bold text-gray-800 mb-4"><?php echo e($data['organization']['name']); ?></h3>
                <p class="text-lg text-primary font-semibold mb-4"><?php echo e($data['organization']['role']); ?></p>
                <p class="text-gray-600 text-justify"><?php echo e($data['organization']['description']); ?></p>
            </div>
        </div>

        <!-- Achievements -->
        <div class="max-w-4xl mx-auto">
            <h3 class="text-2xl font-bold text-gray-800 mb-8 text-center">Pencapaian</h3>
            <div class="space-y-6">
                <?php $__currentLoopData = $data['achievements']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-gray-50 rounded-lg shadow-lg p-6">
                        <div class="flex items-start">
                            <i class="fas fa-trophy text-accent text-2xl mr-4 mt-1"></i>
                            <p class="text-gray-600 text-justify"><?php echo e($achievement); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\dgtme\meila-portfolio\resources\views/portfolio/components/experience.blade.php ENDPATH**/ ?>