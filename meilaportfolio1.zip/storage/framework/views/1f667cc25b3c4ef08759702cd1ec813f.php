<!-- Hero Section -->
<section id="home" class="bg-gradient-to-br from-primary to-secondary text-white py-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center">
            <div class="mb-8">
                <div class="w-32 h-32 bg-white rounded-full mx-auto mb-6 flex items-center justify-center">
                    <i class="fas fa-user text-primary text-6xl"></i>
                </div>
            </div>
            <h1 class="text-4xl md:text-6xl font-bold mb-4"><?php echo e($data['profile']['name']); ?></h1>
            <p class="text-xl md:text-2xl mb-6 text-blue-100"><?php echo e($data['profile']['title']); ?></p>
            <p class="text-lg mb-8 max-w-3xl mx-auto text-blue-50"><?php echo e($data['profile']['bio']); ?></p>
            <div class="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-6 mb-8">
                <div class="flex items-center">
                    <i class="fas fa-map-marker-alt mr-2"></i>
                    <span><?php echo e($data['profile']['location']); ?></span>
                </div>
                <div class="flex items-center">
                    <i class="fas fa-phone mr-2"></i>
                    <span><?php echo e($data['profile']['phone']); ?></span>
                </div>
                <div class="flex items-center">
                    <i class="fas fa-envelope mr-2"></i>
                    <span><?php echo e($data['profile']['email']); ?></span>
                </div>
            </div>
            <a href="#contact" class="bg-white text-primary px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-300 inline-block">
                Get In Touch
            </a>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\dgtme\meila-portfolio\resources\views/portfolio/components/hero.blade.php ENDPATH**/ ?>