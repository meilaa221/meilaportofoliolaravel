<!-- Contact Section -->
<section id="contact" class="py-20 bg-gradient-to-br from-primary to-secondary text-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
            <div class="w-20 h-1 bg-white mx-auto mb-8"></div>
            <p class="text-xl text-blue-100 max-w-2xl mx-auto">
                Tertarik untuk berkolaborasi atau ingin mengetahui lebih lanjut tentang proyek saya? 
                Jangan ragu untuk menghubungi saya!
            </p>
        </div>
        
        <div class="max-w-4xl mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                <div class="text-center">
                    <div class="bg-white bg-opacity-20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-envelope text-2xl"></i>
                    </div>
                    <h3 class="text-lg font-semibold mb-2">Email</h3>
                    <a href="mailto:<?php echo e($data['profile']['email']); ?>" class="text-blue-100 hover:text-white transition duration-300">
                        <?php echo e($data['profile']['email']); ?>

                    </a>
                </div>
                
                <div class="text-center">
                    <div class="bg-white bg-opacity-20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-phone text-2xl"></i>
                    </div>
                    <h3 class="text-lg font-semibold mb-2">Phone</h3>
                    <a href="tel:<?php echo e($data['profile']['phone']); ?>" class="text-blue-100 hover:text-white transition duration-300">
                        <?php echo e($data['profile']['phone']); ?>

                    </a>
                </div>
                
                <div class="text-center">
                    <div class="bg-white bg-opacity-20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-map-marker-alt text-2xl"></i>
                    </div>
                    <h3 class="text-lg font-semibold mb-2">Location</h3>
                    <p class="text-blue-100"><?php echo e($data['profile']['location']); ?></p>
                </div>
            </div>
            
            <div class="text-center">
                <div class="flex flex-col sm:flex-row justify-center gap-4">
                    <a href="mailto:<?php echo e($data['profile']['email']); ?>" 
                       class="bg-white text-primary px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-300 inline-flex items-center justify-center">
                        <i class="fas fa-envelope mr-2"></i>
                        Send Email
                    </a>
                    <a href="#" 
                       class="bg-transparent border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white hover:text-primary transition duration-300 inline-flex items-center justify-center">
                        <i class="fab fa-github mr-2"></i>
                        GitHub
                    </a>
                    <a href="#" 
                       class="bg-transparent border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white hover:text-primary transition duration-300 inline-flex items-center justify-center">
                        <i class="fab fa-linkedin mr-2"></i>
                        LinkedIn
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\dgtme\meila-portfolio\resources\views/portfolio/components/contact.blade.php ENDPATH**/ ?>