<!-- About Section -->
<section id="about" class="py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">About Me</h2>
            <div class="w-20 h-1 bg-primary mx-auto"></div>
        </div>
        <div class="max-w-4xl mx-auto">
            <p class="text-lg text-gray-600 leading-relaxed text-justify">
                <?php echo e($data['profile']['bio']); ?>

            </p>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\dgtme\meila-portfolio\resources\views/portfolio/components/about.blade.php ENDPATH**/ ?>